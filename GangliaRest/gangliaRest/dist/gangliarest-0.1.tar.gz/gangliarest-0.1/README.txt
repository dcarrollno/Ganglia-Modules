GangliaRest
(desc here)

Installing
sudo pip install gangliarest

Usage
service GangliaRest [start|stop|restart\

Example


